<?php


namespace Jet_FB_Address_Autocomplete;


trait AddressConfigBase {

	public function meta_slug() {
		return '_jf_address_autocomplete';
	}

}