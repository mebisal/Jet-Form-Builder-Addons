<?php
/**
 * Point item template
 */

$this->_render_point_content( $item_settings );
