<?php


namespace Jet_FB_Schedule_Forms;

use JetScheduleFormsCore\AttributesTrait;

trait Prevent_Render_Base {

	use AttributesTrait;

	public function maybe_render_schedule_message() {
		$schedule_type = Schedule_Form::get_schedule_type();

		if ( $schedule_type ) {
			$this->add_attribute( 'class', 'jet-form-schedule-message' );

			return $this->render_by_type( $schedule_type );
		}

		return false;
	}

	public function render_by_type( $type ) {
		$content = do_shortcode( Schedule_Form::get_message( $type ) );

		$this->add_attribute( 'class', "$type-message" );

		Schedule_Form::clear();

		ob_start();
		include Plugin::instance()->get_template_path( 'prevent-message' );

		return ob_get_clean();
	}

}