<?php


namespace Jet_FB_Schedule_Forms\Jet_Form_Builder;


use Jet_FB_Schedule_Forms\Plugin;
use Jet_FB_Schedule_Forms\Schedule_Form;
use JetScheduleFormsCore\JetFormBuilder\PluginManager;

class Plugin_Manager extends PluginManager {

	public function plugin_version_compare(): string {
		return '1.2.0';
	}

	/**
	 * @return void
	 */
	public function before_init_editor_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/dist/builder.bundle.js' ),
			array( 'wp-i18n' ),
			Plugin::instance()->get_version(),
			true
		);

		wp_enqueue_style(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/css/editor.css' ),
			array(),
			Plugin::instance()->get_version()
		);
	}

	public function meta_data() {
		return array(
			Schedule_Form::PLUGIN_META_KEY => array()
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Schedule Forms</b> needs <b>JetFormBuilder</b> update.',
			'jet-form-builder-schedule-forms'
		) );
	}

	public function on_base_need_install() {
	}
}