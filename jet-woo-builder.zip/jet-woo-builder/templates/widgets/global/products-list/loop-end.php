<?php
/**
 * Products list widget loop end template.
 *
 * This template can be overridden by copying it to yourtheme/jet-woo-builder/widgets/global/products-list/loop-end.php.
 */
?>
</ul>
