<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;


class General extends RestrictTypeBase {

	const SUBMISSIONS_KEY = '_form_submissions';

	public function get_id() {
		return 'general';
	}

	public function limit_submissions( $settings, $form_id ) {
		return $this->get_general_limit();
	}

	public function count_submissions( $settings, $form_id ) {
		$count = 0;
		$counters = self::counters( $form_id );

		if ( isset( $counters[ self::SUBMISSIONS_KEY ] ) ) {
			$count = $counters[ self::SUBMISSIONS_KEY ]['count'];
		}

		return ( (int) $count );
	}

	public function increment_submissions( $settings, $form_id ) {
		$counters = self::counters( $form_id );

		$counters[ self::SUBMISSIONS_KEY ] = isset( $counters[ self::SUBMISSIONS_KEY ] )
			? $counters[ self::SUBMISSIONS_KEY ]
			: array( 'count' => 0 );

		$counters[ self::SUBMISSIONS_KEY ]['count'] ++;

		return $this->update_counters_json_meta( $counters, $form_id );
	}

	private function get_general_limit() {
		$settings = self::settings();

		if ( isset( $settings['limit'] ) && $settings['limit'] >= 1 ) {
			return (int) $settings['limit'];
		}

		return 1;
	}
}