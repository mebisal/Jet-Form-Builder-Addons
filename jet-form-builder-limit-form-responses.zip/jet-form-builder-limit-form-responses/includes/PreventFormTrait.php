<?php


namespace Jet_FB_Limit_Form_Responses;


use Jet_FB_Limit_Form_Responses\Exceptions\LimitException;

trait PreventFormTrait {

	protected $is_reached = false;
	protected $message;
	protected $type;

	public function run_increment() {
		return true;
	}

	abstract public function get_message_type_on_general_limit();

	abstract public function get_message_type_on_restrict_limit();

	abstract public function send_response_or_process( $form_id, $handler );

	protected function send_response_on_reached_limit( $form_id, $handler = null ) {
		try {

			LimitResponses::instance()->has_reached_general_limit(
				$this->get_message_type_on_general_limit(),
				$form_id,
				$this->run_increment()
			);
			LimitResponses::instance()->has_reached_restrict_limit(
				$this->get_message_type_on_restrict_limit(),
				$form_id,
				$this->run_increment()
			);

		} catch ( LimitException $exception ) {
			$this->is_reached = true;
			$this->type       = $exception->getMessage();
			$this->message    = LimitResponses::instance()->get_message_by_type( $this->type );
		}
		$response = $this->send_response_or_process( $form_id, $handler );

		LimitResponses::clear();
		$this->is_reached = false;
		$this->type       = null;
		$this->message    = null;

		return $response;
	}


}