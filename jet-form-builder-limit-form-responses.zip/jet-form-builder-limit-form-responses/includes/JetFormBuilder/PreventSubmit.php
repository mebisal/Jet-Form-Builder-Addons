<?php


namespace Jet_FB_Limit_Form_Responses\JetFormBuilder;

use Jet_FB_Limit_Form_Responses\PreventSubmitTrait;
use Jet_Form_Builder\Form_Messages\Manager;
use JetLimitResponsesCore\JetFormBuilder\PreventFormSubmit;

class PreventSubmit extends PreventFormSubmit {

	use PreventSubmitTrait;

	/**
	 * @inheritDoc
	 */
	public function prevent_process_ajax_form( $handler ) {
		$this->send_response_on_reached_limit( $handler->form_id, $handler );
	}

	/**
	 * @inheritDoc
	 */
	public function prevent_process_reload_form( $handler ) {
		$this->send_response_on_reached_limit( $handler->form_id, $handler );
	}


	public function send_response_or_process( $form_id, $handler ) {
		if ( ! $this->is_reached ) {
			return;
		}

		$handler->send_response( array(
			'status' => Manager::dynamic_error( $this->message )
		) );
	}
}