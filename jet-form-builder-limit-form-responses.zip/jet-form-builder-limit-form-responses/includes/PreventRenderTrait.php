<?php


namespace Jet_FB_Limit_Form_Responses;


use JetLimitResponsesCore\AttributesTrait;

trait PreventRenderTrait {

	use AttributesTrait;
	use PreventFormTrait;

	public function run_increment() {
		return false;
	}

	public function render_form( $form_id, $attrs, $prev_content ) {
		return $prev_content ? $prev_content : $this->send_response_on_reached_limit( $form_id );
	}

	public function get_message_type_on_general_limit() {
		return LimitResponses::CLOSED_MESSAGE;
	}

	public function get_message_type_on_restrict_limit() {
		return LimitResponses::RESTRICT_MESSAGE;
	}

	public function send_response_or_process( $form_id, $handler ) {
		return $this->is_reached ? $this->render_limit_message() : false;
	}

	public function render_limit_message() {
		$this->add_attribute( 'class', 'jet-form-limit-message' );
		$this->add_attribute( 'class', $this->type );
		$content = do_shortcode( $this->message );

		ob_start();
		include Plugin::instance()->get_template_path( 'prevent-message' );
		return ob_get_clean();
	}

}