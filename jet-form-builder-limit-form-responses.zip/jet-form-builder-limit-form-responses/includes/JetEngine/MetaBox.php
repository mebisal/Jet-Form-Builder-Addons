<?php


namespace Jet_FB_Limit_Form_Responses\JetEngine;


use Jet_FB_Limit_Form_Responses\LimitResponses;
use Jet_FB_Limit_Form_Responses\Plugin;
use JetLimitResponsesCore\JetEngine\RegisterFormMetaBox;

class MetaBox extends RegisterFormMetaBox {

	public function get_id() {
		return LimitResponses::PLUGIN_META_KEY;
	}

	public function get_title() {
		return __( 'Limit Form Responses', 'jet-form-builder' );
	}

	public function get_fields() {
		ob_start();
		include Plugin::instance()->get_template_path( 'meta-box' );
		$content = ob_get_clean();

		return array(
			$this->get_id() => array(
				'type' => 'html',
				'html' => $content,
			)
		);
	}

	public function register_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/dist/engine.bundle.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);

		wp_localize_script(
			Plugin::instance()->slug,
			'JetLimitFormResponses',
			array(
				'meta' => LimitResponses::instance()->get_settings()
			)
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Limit Form Responses</b> needs <b>JetEngine</b> update.',
			'jet-form-builder-limit-form-responses'
		) );
	}

	public function on_base_need_install() {
	}
}