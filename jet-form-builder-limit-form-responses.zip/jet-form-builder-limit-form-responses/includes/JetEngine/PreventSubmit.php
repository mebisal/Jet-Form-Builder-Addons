<?php


namespace Jet_FB_Limit_Form_Responses\JetEngine;

use Jet_FB_Limit_Form_Responses\PreventSubmitTrait;
use JetLimitResponsesCore\JetEngine\PreventFormSubmit;

class PreventSubmit extends PreventFormSubmit {

	use PreventSubmitTrait;

	/**
	 * @inheritDoc
	 */
	public function prevent_process_ajax_form( $handler ) {
		$this->send_response_on_reached_limit( $handler->form, $handler );
	}

	/**
	 * @inheritDoc
	 */
	public function prevent_process_reload_form( $handler ) {
		$this->send_response_on_reached_limit( $handler->form, $handler );
	}


	public function send_response_or_process( $form_id, $handler ) {
		if ( ! $this->is_reached ) {
			return;
		}

		$handler->redirect( array(
			'status' => $this->message
		) );
	}
}