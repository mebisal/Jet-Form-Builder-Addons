const { __ } = wp.i18n;

const labels = {
	enable: __( 'Limit Form Responses' ),
	limit: __( 'Limit' ),
	closed_message: __( 'Closed Message' ),
	error_message: __( 'Error message' ),
	restrict_users: __( 'Restrict users from multiple responses' ),
	restrict_by: __( 'Restrict users by' ),
	guest_message: __( 'Not logged in message' ),
	restricted_message: __( 'Restricted message' ),
};

const help = {
	closed_message: __( 'Text to display instead of form if form submission limit has been reached. You can use shortcodes here' ),
	error_message: __( 'The error text that is displayed when trying to submit a form with an increased limit of submissions' ),
	restrict_users: __( 'If this is enabled, then one user will be able to submit the form only once' ),
	restricted_message: __( 'Text to display instead of a form if the user has already submitted it. You can use shortcodes here' )
};

const { applyFilters } = wp.hooks;

const options = {
	restrict_by: applyFilters( 'jet.fb.limitFormResponses.register.restrict_by', [
		{
			value: '',
			label: __( 'IP address' )
		},
		{
			value: 'user',
			label: __( 'Logged in users' )
		},
		{
			value: 'cookie',
			label: __( 'Cookie value' )
		},
		{
			value: 'session',
			label: __( 'Session value' )
		}
	] )
};

export {
	labels,
	help,
	options
};