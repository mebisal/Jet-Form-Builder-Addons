import PluginLimitFormResponses from "./render";

const { __ } = wp.i18n;

const base = {
	name: 'jf-limit-responses-panel',
	title: __( 'Limit Form Responses' )
};

const settings = {
	render: PluginLimitFormResponses,
	icon: null
};

export {
	base,
	settings
};