# JetFormBuilder Hubspot Action
Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.1.2
* Tweak: Removed unnecessary hook

## 1.1.1
* Tweak: add license manager

## 1.1.0
* ADD: OAuth 2.0 authorization

## 1.0.0
* Initial release
