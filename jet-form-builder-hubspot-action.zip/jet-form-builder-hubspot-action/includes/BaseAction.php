<?php


namespace Jet_FB_HubSpot;


use HubSpot\Client\Crm\Contacts\ApiException;
use HubSpot\Client\Crm\Contacts\Model\SimplePublicObjectInput;
use JetHubSpotCore\Exceptions\ApiHandlerException;
use JetHubSpotCore\Exceptions\BaseHandlerException;
use JetHubSpotCore\JetFormBuilder\ActionCompatibility;

trait BaseAction {

	use ActionCompatibility;

	public function get_name() {
		return __( 'HubSpot', 'jet-form-builder-hubspot-action' );
	}

	public function get_id() {
		return 'hubspot';
	}


	private function set_token_or_key() {
		$settings = $this->getSettings();

		if ( ! isset( $settings['use_global'] ) || ! $settings['use_global'] ) {
			Handler::instance()->set_arg( 'api_key', $settings['api_key'] );

			return;
		}

		$settings['namespace'] = $this->provider_slug();

		Handler::instance()->set_args_from( $settings );
	}

	/**
	 * Run a hook notification
	 *
	 * @return void
	 * @throws BaseHandlerException
	 */
	public function run_action() {
		$this->set_token_or_key();

		$properties = $this->prepare_properties( $this->getSettings() );

		if ( ! isset( $properties['email'] ) || ! $properties['email'] ) {
			$message = $this->parseDynamicException(
				'error',
				__( 'The email field is required.', 'jet-form-builder-hubspot-action' )
			);
			throw new BaseHandlerException( $message );
		}

		$contactInput = new SimplePublicObjectInput();
		$contactInput->setProperties( $properties );

		try {
			Handler::instance()
			       ->hubspot()
			       ->crm()
			       ->contacts()
			       ->basicApi()
			       ->create( $contactInput );

		} catch ( ApiHandlerException $exception ) {
			throw new BaseHandlerException(
				$this->parseDynamicException( 'error', $exception->getMessage() )
			);
		} catch ( ApiException $exception ) {
			$response = json_decode( $exception->getResponseBody(), true, 10 );
			$matches  = array();
			$message  = $response['message'];

			preg_match( '/^.*(\[.+\])$/', $message, $matches );

			if ( isset( $matches[1] ) ) {
				$messages = json_decode( $matches[1], true );

				$message = implode( '; ', array_map( function ( $error ) {
					return $error['message'];
				}, $messages ) );
			}

			throw new BaseHandlerException(
				$this->parseDynamicException( 'error', $message )
			);
		}
	}

	/**
	 * @param $settings
	 *
	 * @return array
	 * @throws BaseHandlerException
	 */
	public function prepare_properties( $settings ) {
		$request  = $this->getRequest();
		$response = array();

		if ( empty( $settings['fields_map'] ) ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		foreach ( Handler::instance()->properties_insert() as $property ) {
			if ( isset( $settings[ $property ] ) ) {
				$response[ $property ] = $settings[ $property ];
			} elseif (
				isset( $settings['fields_map'][ $property ] )
				&& ! empty( $settings['fields_map'][ $property ] )
				&& ! empty( $request[ $settings['fields_map'][ $property ] ] )
			) {
				$field_name            = $settings['fields_map'][ $property ];
				$response[ $property ] = $request[ $field_name ];
			}
		}

		return $response;
	}

}