<?php
/**
 * Plugin Name: JetFormBuilder HubSpot Action
 * Plugin URI:  https://jetformbuilder.com/addons/hubspot/
 * Description: A mailing list addon that lets you alter the existing contacts and easily add new ones.
 * Version:     1.1.2
 * Author:      Crocoblock
 * Author URI:  https://crocoblock.com/
 * Text Domain: jet-form-builder-hubspot-action
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_FB_HUBSPOT_ACTION_VERSION', '1.1.2' );

define( 'JET_FB_HUBSPOT_ACTION__FILE__', __FILE__ );
define( 'JET_FB_HUBSPOT_ACTION_PLUGIN_BASE', plugin_basename( __FILE__ ) );
define( 'JET_FB_HUBSPOT_ACTION_PATH', plugin_dir_path( __FILE__ ) );
define( 'JET_FB_HUBSPOT_ACTION_URL', plugins_url( '/', __FILE__ ) );

if ( version_compare( PHP_VERSION, '7.2.5', '>=' ) ) {
	require 'vendor/autoload.php';

	add_action( 'plugins_loaded', function () {
		require JET_FB_HUBSPOT_ACTION_PATH . 'includes/plugin.php';
	}, 100 );
} else {
	add_action( 'admin_notices', function () {
		$class   = 'notice notice-error';
		$message = __(
			'<b>Error:</b> <b>JetFormBuilder HubSpot Action</b> plugin requires a PHP version ">= 7.2.5" to work properly!',
			'jet-form-builder-hubspot-action'
		);
		printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $message ) );
	} );
}

