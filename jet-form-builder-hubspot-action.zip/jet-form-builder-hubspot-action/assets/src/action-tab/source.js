const { __ } = wp.i18n;

const label = {
	api_key: __( 'API key', 'jet-form-builder-hubspot-action' ),
	client_id: __( 'Client ID', 'jet-form-builder-hubspot-action' ),
	client_secret: __( 'Client Secret', 'jet-form-builder-hubspot-action' ),
	use_oauth: __( 'Enable OAuth 2.0', 'jet-form-builder-hubspot-action' ),
	redirect_uri: __( 'Install URL (OAuth)', 'jet-form-builder-hubspot-action' ),
	redirect_base: __( 'Your Redirect URL', 'jet-for-builder-hubspot-action' ),
	redirect_btn: __( 'Authorize', 'jet-for-builder-hubspot-action' ),
};

const help = {
	client_id: __( 'Your app\'s client ID', 'jet-form-builder-hubspot-action' ),
	client_secret: __( 'Your app\'s client secret', 'jet-form-builder-hubspot-action' ),
	redirect_base: __( 'You need to paste this URL to Redirect URL input in App\'s Auth Settings', 'jet-form-builder-hubspot-action' ),
	redirect_uri: __( 'Copy and paste the link here that can be found in the settings of your Hubspot App', 'jet-form-builder-hubspot-action' ),
	redirect_btn: __( 'Click this button to log in via OAuth 2.0', 'jet-for-builder-hubspot-action' ),
	api_key: __( `
	How to obtain your HubSpot API key? More info
	<a href="https://knowledge.hubspot.com/integrations/how-do-i-get-my-hubspot-api-key">here</a>
	`,
		'jet-form-builder-hubspot-action',
	),
	use_oauth: __( `
	Note: this type of authorization is for advanced users only.
	More info <a href="https://developers.hubspot.com/docs/api/working-with-oauth">here</a>
	`,
		'jet-form-builder-hubspot-action',
	),
};

export {
	label,
	help,
};