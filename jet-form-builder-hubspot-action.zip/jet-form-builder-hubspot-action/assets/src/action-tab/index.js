import ActionTab from './ActionTab.vue';

const { __ } = wp.i18n;

const title = __( 'HubSpot API', 'jet-form-builder' );
const component = ActionTab;

export {
	title,
	component
}