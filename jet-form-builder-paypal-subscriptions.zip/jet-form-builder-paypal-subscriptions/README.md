# JetFormBuilder Paypal Subscriptions
A tweak that allows you to create subscriptions and accept recurring payments via PayPal-integrated forms.
