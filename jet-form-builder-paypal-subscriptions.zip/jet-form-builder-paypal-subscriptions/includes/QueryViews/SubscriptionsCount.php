<?php


namespace Jet_FB_Paypal\QueryViews;


use Jet_Form_Builder\Db_Queries\Views\View_Base_Count_Trait;

class SubscriptionsCount extends SubscriptionsView {

	use View_Base_Count_Trait;

}