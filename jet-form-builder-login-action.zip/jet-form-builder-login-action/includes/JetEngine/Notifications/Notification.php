<?php


namespace Jet_FB_Login\JetEngine\Notifications;

use Jet_FB_Login\ActionTrait;
use JetLoginCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use ActionTrait;

}