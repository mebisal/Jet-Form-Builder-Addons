import {
	label,
	option,
} from './source';

const {
		  addFilter,
	  } = wp.hooks;

const { __ } = wp.i18n;

const parentBlockName = 'jet-forms/color-picker-field';

addFilter( 'blocks.registerBlockType', 'jet-form-builder', ( props, name ) => {
	if ( name !== parentBlockName ) {
		return props;
	}

	props.attributes.preferredFormat = {
		type: "string",
		default: "",
	};
	props.attributes.showAlpha = {
		type: "boolean",
		default: true,
	};
	props.attributes.use_advanced = {
		type: "boolean",
		default: true,
	};

	return props;
} );

addFilter( 'jet.fb.register.fields.controls', 'jet-form-builder', controls => {
	controls.custom_settings = controls.custom_settings || {};
	controls.custom_settings.attrs = controls.custom_settings.attrs || [];

	controls.custom_settings.attrs.push(
		{
			"attrName": "use_advanced",
			"label": label( 'use_advanced' ),
			"type": "toggle",
			condition: {
				blockName: [ parentBlockName ],
			},
		},
		{
			"attrName": "preferredFormat",
			"label": label( 'preferredFormat' ),
			"type": "select",
			"options": option( 'preferredFormat' ),
			condition: {
				attr: 'use_advanced',
				blockName: [ parentBlockName ],
			},
		},
		{
			"attrName": "showAlpha",
			"label": label( 'showAlpha' ),
			"type": "toggle",
			condition: {
				attr: 'use_advanced',
				blockName: [ parentBlockName ],
			},
		},
	);

	return controls;
} );
