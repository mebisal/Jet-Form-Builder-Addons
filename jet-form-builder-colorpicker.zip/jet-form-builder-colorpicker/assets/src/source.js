const { __ } = wp.i18n;

const labels = {
	use_advanced: __( 'Use advanced Color Picker', 'jet-form-builder-colorpicker' ),
	preferredFormat: __( 'Value Format', 'jet-form-builder-colorpicker' ),
	showAlpha: __( 'Show Alpha (opacity)', 'jet-form-builder-colorpicker' ),
};

const options = {
	preferredFormat: [
		{
			value: "hex",
			label: __( 'Hex', 'jet-form-builder-colorpicker' ),
		},
		{
			value: "rgb",
			label: __( 'Rgb', 'jet-form-builder-colorpicker' ),
		},
	],
}

const label = arg_name => labels[ arg_name ] || '[Empty label]';

const placeholder = {
	value: "",
	label: "--",
};
const option = ( option_name, with_placeholder = true ) => {
	const source = with_placeholder ? [ placeholder ] : [];

	source.push( ...( options[ option_name ] || [] ) );

	return source;
}

export {
	label,
	option,
};