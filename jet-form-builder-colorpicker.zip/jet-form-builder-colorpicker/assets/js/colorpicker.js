( function( $ ) {
	const { applyFilters } = wp.hooks;

	function initColorPicker( event, $scope ) {
		$( '.jet-fb-color-picker-advanced', $scope ).each( function() {
			const self = $( this );

			const settings = self.data( 'fb-settings' );

			self.spectrum( applyFilters( 'jet.fb.colorpicker.options', {
				type: "component",
				togglePaletteOnly: true,
				...settings,
			} ) );
		} )
	}

	$( document ).on(
		'jet-form-builder/init',
		initColorPicker,
	);
	$( document ).on(
		'jet-engine/booking-form/init',
		initColorPicker,
	);

	function initFromRepeater( e, namespace ) {
		const repeater = $( e.target ).closest( `.${ namespace }-repeater` );

		initColorPicker( e, $( `.${ namespace }-repeater__row:last`, repeater ) )
	}


	$( document ).on(
		'jet-form-builder/repeater-add-new',
		'.jet-form-builder-repeater__new',
		e => initFromRepeater( e, 'jet-form-builder' )
	);

	$( document ).on(
		'jet-engine/form/repeater-add-new',
		'.jet-form-repeater__new',
		e => initFromRepeater( e, 'jet-form' )
	);
} )( jQuery )