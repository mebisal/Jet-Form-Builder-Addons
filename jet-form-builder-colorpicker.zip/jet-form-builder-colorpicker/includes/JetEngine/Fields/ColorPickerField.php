<?php


namespace Jet_FB_ColorPicker\JetEngine\Fields;

use JetColorPickerCore\JetEngine\SingleField;

class ColorPickerField extends SingleField {

	/**
	 * @return string
	 */
	public function get_id() {
		return 'color_picker_field';
	}

	/**
	 * @return string
	 */
	public function get_title() {
		return __( 'Color Picker Field', 'jet-form-builder-colorpicker' );
	}

	/**
	 * @return string
	 */
	public function get_field_template( $template, $args, $builder ) {
		return ( new ColorPickerFieldRender() )->set_up( $args, $builder )->get_rendered();
	}

}