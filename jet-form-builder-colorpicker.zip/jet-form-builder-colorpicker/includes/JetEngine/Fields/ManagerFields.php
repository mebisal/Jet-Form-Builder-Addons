<?php


namespace Jet_FB_ColorPicker\JetEngine\Fields;


use Jet_FB_ColorPicker\Plugin;
use JetColorPickerCore\JetEngine\FieldsManager;

class ManagerFields extends FieldsManager {

	public function fields() {
		return array(
			new ColorPickerField()
		);
	}

	public function register_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/dist/engine.editor.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Advanced Color Picker</b> needs <b>JetEngine</b> update.',
			'jet-form-builder-colorpicker'
		) );
	}

	public function on_base_need_install() {
	}
}