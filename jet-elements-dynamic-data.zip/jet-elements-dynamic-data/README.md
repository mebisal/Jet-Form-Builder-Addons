## Available Filters
- **post_url_by_id** - get the Post URL by Post ID
- **post_title_by_id** - get the Post Title by Post ID
- **render_fa_icon** - get a Font Awesome icon classes

Usage example: **key_name|filter_name** http://prntscr.com/qwsmzx