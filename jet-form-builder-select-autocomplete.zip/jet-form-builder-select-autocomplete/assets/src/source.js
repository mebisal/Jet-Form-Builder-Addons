const { __ } = wp.i18n;

export default {
	autocomplete_enable:             {
		label: __( 'Use Autocomplete' ),
		help:  __( 'Adding a text box to search among options', 'jet-form-builder-select-autocomplete' ),
	},
	autocomplete_via_ajax:           {
		label: __( 'Loading via AJAX' ),
	},
	autocomplete_minimumInputLength: {
		label: __( 'Minimum input length' ),
		help:  __( 'Number of characters required to perform a search', 'jet-form-builder-select-autocomplete' ),
	},
}