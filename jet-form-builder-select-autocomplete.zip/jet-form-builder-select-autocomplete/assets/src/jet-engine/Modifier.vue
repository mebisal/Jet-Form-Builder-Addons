<template>
	<div class="select-autocomplete">
		<JetFormEditorRow :label="autocomplete_enable.label">
			<input type="checkbox" v-model="response.autocomplete_enable">
			<template v-slot:helpSide>{{ autocomplete_enable.help }}</template>
		</JetFormEditorRow>
		<JetFormEditorRow :label="autocomplete_via_ajax.label" v-if="response.autocomplete_enable">
			<input type="checkbox" v-model="response.autocomplete_via_ajax">
		</JetFormEditorRow>
		<JetFormEditorRow :label="autocomplete_minimumInputLength.label" v-if="response.autocomplete_enable">
			<input type="number" v-model="response.autocomplete_minimumInputLength">
			<template v-slot:helpControl>{{ autocomplete_minimumInputLength.help }}</template>
		</JetFormEditorRow>
	</div>
</template>

<script>
import { JetFormEditorRow } from 'jfb-editor';
import source from '../source';

export default {
	name:       'modify_select',
	components: {
		JetFormEditorRow,
	},
	props:      [ 'value' ],
	data() {
		return {
			response:                        {},
			autocomplete_enable:             source.autocomplete_enable,
			autocomplete_via_ajax:           source.autocomplete_via_ajax,
			autocomplete_minimumInputLength: source.autocomplete_minimumInputLength,
		}
	},
	created() {
		this.response = { ...this.response, ...this.value };
	},
	watch:      {
		response( newResponse ) {
			this.$emit( 'input', newResponse );
		},
	},
	methods:    {},
}

</script>