( function( $ ) {
	function initSelect2( event, $scope ) {
		const { applyFilters } = wp.hooks;

		const getAjaxObject = scope => {
			let action = 'jet_forms_select_autocomplete__';
			action += scope.hasClass( 'jet-form-builder__field' ) ? 'jfb' : 'jef';

			return {
				ajax: applyFilters( 'jet.fb.select_autocomplete.ajax', {
					delay: 250,
					type: 'POST',
					dataType: 'json',
					data: function( { term } ) {
						return {
							action, term,
							fieldName: scope.attr( 'data-field-name' ),
							formId: scope.closest( 'form' ).data( 'form-id' ),
						};
					},
					processResults: function( response ) {
						if ( response.success ) {
							return { results: response.data }
						}
						return { results: [] };
					},
				} ),
			}
		};

		$( '.jet-select-autocomplete', $scope ).each( function() {
			const self = $( this );
			let selectOptions = {};

			if ( self.data( 'ajax--url' ) ) {
				selectOptions = { ...selectOptions, ...getAjaxObject( self ) }
			}

			self.select2( applyFilters( 'jet.fb.select_autocomplete.options', selectOptions, self ) );
		} )
	}

	function initFromRepeater( e, namespace ) {
		const repeater = $( e.target ).closest( `.${ namespace }-repeater` );

		initSelect2( e, $( `.${ namespace }-repeater__row:last`, repeater ) )
	}

	$( document ).on(
		'jet-form-builder/init',
		initSelect2,
	);

	$( document ).on(
		'jet-engine/booking-form/init',
		initSelect2,
	);

	$( document ).on(
		'jet-form-builder/repeater-add-new',
		'.jet-form-builder-repeater__new',
		e => initFromRepeater( e, 'jet-form-builder' )
	);

	$( document ).on(
		'jet-engine/form/repeater-add-new',
		'.jet-form-repeater__new',
		e => initFromRepeater( e, 'jet-form' )
	);
} )( jQuery )