<?php


namespace Jet_FB_SelectAutocomplete\JetEngine;


use Jet_FB_SelectAutocomplete\BaseSelectModifier;
use Jet_FB_SelectAutocomplete\Plugin;
use JetSelectAutocompleteCore\JetEngine\BaseFieldModifier;

class SelectModifier extends BaseFieldModifier {

	use BaseSelectModifier;

	public function type(): string {
		return 'select';
	}

	public function editorAssets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/js/engine.editor.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}
	
	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Select Autocomplete</b> needs <b>JetEngine</b> update.',
			'jet-form-builder-select-autocomplete'
		) );
	}

	public function on_base_need_install() {
	}


}