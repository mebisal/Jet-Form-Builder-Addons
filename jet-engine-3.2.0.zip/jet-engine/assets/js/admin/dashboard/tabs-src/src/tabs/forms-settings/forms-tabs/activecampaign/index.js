import ActiveCampaign from './ActiveCampaignTab.vue';

const { __ } = wp.i18n;

const title = __( 'ActiveCampaign API', 'jet-form-builder' );
const component = ActiveCampaign;

export {
	title,
	component
}