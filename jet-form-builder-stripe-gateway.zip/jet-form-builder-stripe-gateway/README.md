# JetFormBuilder Stripe Gateway
Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.0.4
* FIX: JetAppointment compatibility

## 1.0.3
* ADD: filter `jet-form-builder/stripe/payment-methods`, for change payment method types
* Tweak: Removed unnecessary hook

## 1.0.2
* Tweak: add license manager

## 1.0.1
* FIX: Error when global settings did not use

## 1.0.0
* Initial release
