<?php


namespace Jet_FB_HR_Select\JetFormBuilder\Blocks;


use JetHRSelectCore\JetFormBuilder\BlocksParserManager;

class ParserManager extends BlocksParserManager {

	public function parsers(): array {
		return array(
			new HrSelectParser()
		);
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}
}