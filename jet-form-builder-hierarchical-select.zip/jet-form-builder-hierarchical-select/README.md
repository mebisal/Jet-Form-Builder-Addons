# JetFormBuilder Hierarchical Select
Premium Addon for JetFormBuilder

# ChangeLog

## 1.0.1
* FIX: Fatal error when disabling JetFormBuilder

## 1.0.0
* Initial release