import HrSelectEdit from "./edit";
import metadata from "./block.json";

const { __ } = wp.i18n;

const { name, icon } = metadata;

/**
 * Available items for `useEditProps`:
 *  - uniqKey
 *  - formFields
 *  - blockName
 *  - attrHelp
 */
const settings = {
	title: __( 'Hierarchical Select' ),
	icon: <span dangerouslySetInnerHTML={ { __html: icon } }></span>,
	edit: HrSelectEdit,
	useEditProps: [ 'uniqKey', 'blockName', 'attrHelp', 'source' ],
	example: {
		attributes: {
			label: 'Hierarchical Select',
			desc: 'Field description...',
		},
	},
};

export {
	metadata,
	name,
	settings,
};