import FieldComponent from './FieldComponent.vue';

const { addFilter } = wp.hooks;

addFilter( 'jet.engine.register.fields', 'jet-engine', fields => {
	fields.push( FieldComponent );

	return fields;
} );

const hrBlockName = 'hr_select';

const getBlocksByType = ( source, blockNames ) => {
	const blocks = [];
	const names = [];

	source.forEach( block => {
		if ( ! blockNames.includes( block.type ) ) {
			return;
		}
		blocks.push( block );
		names.push( block.name );
	} );

	return [ blocks, names ];
};

addFilter( 'jet.engine.form.fields', 'jet-form-builder-hr-select', ( fields, fieldWithSettings ) => {
	const [ hrSelects, hrSelectsNames ] = getBlocksByType( fieldWithSettings, [ hrBlockName ] );

	fields = fields.filter( field => (
		! hrSelectsNames.includes( field )
	) );

	for ( const hrSelect of hrSelects ) {

		if ( ! hrSelect.hr_select || ! hrSelect.name || ! hrSelect.hr_select.levels ) {
			continue;
		}
		for ( const level of hrSelect.hr_select.levels ) {
			if ( ! level.name ) {
				continue;
			}
			fields.push( level.name );
		}
	}

	return fields;
} );

