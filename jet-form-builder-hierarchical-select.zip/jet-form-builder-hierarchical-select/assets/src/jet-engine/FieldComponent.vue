<template>
	<div>
		<JetFormEditorRow class="jet-hr-select-border-top" :label="source.label( 'manage_levels_button' )">
			<button type="button" class="button button-secondary" @click="toggleModal">
				{{ source.label( 'modal' ) }}
			</button>
		</JetFormEditorRow>
		<JetFormEditorRow :label="source.label( 'parent_taxonomy' )">
			<select v-model="response.parent_taxonomy">
				<option v-for="({ value, label }) in source.taxonomies" :value="value">{{ label }}</option>
			</select>
		</JetFormEditorRow>
		<JetFormEditorRow :label="source.label( 'term_value' )">
			<select v-model="response.term_value">
				<option v-for="({ value, label }) in source.term_value" :value="value">{{ label }}</option>
			</select>
		</JetFormEditorRow>
		<JetFormEditorRow v-if="'meta' === response.term_value" :label="source.label( 'term_meta_value' )">
			<input type="text" v-model="response.term_meta_value">
		</JetFormEditorRow>
		<JetFormEditorRow :label="source.label( 'calc_from_meta' )">
			<input type="checkbox" v-model="response.calc_from_meta">
		</JetFormEditorRow>
		<JetFormEditorRow v-if="response.calc_from_meta" :label="source.label( 'term_calc_value' )">
			<input type="text" v-model="response.term_calc_value">
			<template #helpControl>
				{{ source.help( 'term_calc_value' ) }}
			</template>
		</JetFormEditorRow>
		<FormEditorModalHrSelect
			:header="source.label( 'modal' )"
			v-if="isVisibleModal"
			@on-cancel-modal="toggleModal"
			done-button="Save"
		>
			<JfbRepeater
				:incoming-items="response.levels || []"
				:single-item="source.default_item"
				@change-items="onChangeItems"
				:button-add-label="source.label( 'add_new_level' )"
			>
				<template #default="{ current, currentIndex, changeCurrent }">
					<div v-if="0 !== currentIndex && ! response.calc_from_meta">
						<label :for="'as_text_' + currentIndex">{{ source.label( 'level_display_input' ) }}</label>
						<div class="item-control">
							<input
								type="checkbox"
								:checked="current.display_input"
								@change="changeCurrent( { display_input: $event.target.checked } )"
								:id="'label_' + currentIndex"
							/>
							<div class="jet-form-editor__row-notice">{{ source.help( 'level_display_input' ) }}</div>
						</div>
					</div>
					<div>
						<label :for="'label_' + currentIndex">{{ source.label( 'level_name' ) }}</label>
						<input
							type="text"
							:value="current.name"
							@change="changeCurrent( { name: $event.target.value } )"
							@focusin="() => {
								if ( current.name ) {
									return;
								}
								changeCurrent( { name: `${ allSettings.name }_level_${ currentIndex }` } )
							}"
							:id="'label_' + currentIndex"
							class="item-control"
						>
					</div>
					<div>
						<label :for="'label_' + currentIndex">{{ source.label( 'level_label' ) }}</label>
						<input
							type="text"
							:value="current.label"
							@change="changeCurrent( { label: $event.target.value } )"
							:id="'label_' + currentIndex"
							class="item-control"
						>
					</div>
					<div>
						<label :for="'label_' + currentIndex">{{ source.label( 'level_placeholder' ) }}</label>
						<input
							type="text"
							:value="current.placeholder"
							@change="changeCurrent( { placeholder: $event.target.value } )"
							:id="'label_' + currentIndex"
							class="item-control"
						>
					</div>
					<div>
						<label :for="'label_' + currentIndex">{{ source.label( 'level_description' ) }}</label>
						<input
							type="text"
							:value="current.desc"
							@change="changeCurrent( { desc: $event.target.value } )"
							:id="'label_' + currentIndex"
							class="item-control"
						>
					</div>
				</template>
			</JfbRepeater>
		</FormEditorModalHrSelect>
	</div>
</template>

<style lang="scss" scoped>
.jet-hr-select-border-top {
	border-top: 1px solid #ddd;
}

.jet-form-repeater-ui__item--controls {
	& > div {
		display: flex;
		justify-content: space-between;
		&:not(:last-child) {
			border-bottom: 1px solid #ddd;
			margin-bottom: 1em;
			padding-bottom: 1em;
		}
		& > label {
			flex: 1.2;
		}
		& > .item-control {
			flex: 3 0 10%;
		}
	}
}
</style>

<script>
import {
	JetFormEditorRow,
	Blocks,
} from "jfb-editor";
import FormEditorModalHrSelect from './FormEditorModalHrSelect';
import JfbRepeater from './JfbRepeater';

export default {
	name: 'hr_select',
	components: {
		JetFormEditorRow,
		JfbRepeater,
		FormEditorModalHrSelect,
	},
	props: [ 'value', 'allSettings' ],
	data() {
		return {
			response: {},
			source: Blocks.getFieldSource( 'hr_select' ),
			isVisibleModal: false,
		}
	},
	created() {
		this.response = { ...this.response, ...this.value };
	},
	watch: {
		response( newResponse ) {
			this.$emit( 'input', newResponse );
		},
	},
	methods: {
		toggleModal() {
			this.isVisibleModal = ! this.isVisibleModal;
		},
		onChangeItems( levels ) {
			this.$set( this.response, 'levels', levels );
			this.isVisibleModal = false;
		},
	},
};
</script>
