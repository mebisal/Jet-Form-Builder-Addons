<?php


namespace Jet_FB_MailPoet;


use JetMailPoetCore\Exceptions\BaseHandlerException;
use JetMailPoetCore\JetFormBuilder\ActionCompatibility;
use JetMailPoetCore\SmartNotificationActionTrait;
use MailPoet\API\MP\v1\APIException;

/**
 * @method SmartNotificationActionTrait getSettings()
 * @method SmartNotificationActionTrait getRequestData()
 * @method SmartNotificationActionTrait getSettingsWithGlobal()
 * @method SmartNotificationActionTrait getGlobalOptionName()
 * @method SmartNotificationActionTrait parseDynamicException( $type, $message )
 *
 * Trait BaseAction
 * @package Jet_FB_MailPoet
 */
trait BaseAction {

	use ActionCompatibility;

	public function get_name() {
		return __( 'MailPoet', 'jet-form-builder-mailpoet-action' );
	}

	public function get_id() {
		return 'mailpoet';
	}

	/**
	 * @param $api_key
	 *
	 * @return mixed
	 */
	public function handler(): Handler {
		return Handler::instance();
	}

	/**
	 * Run a hook notification
	 *
	 * @return void
	 * @throws BaseHandlerException
	 */
	public function run_action() {
		$settings   = $this->getSettings();
		$subscriber = $this->prepare_subscriber();
		$list_ids   = $this->prepare_list_ids();

		try {
			$this->handler()->api()->addSubscriber( $subscriber, $list_ids, $settings );
		} catch ( APIException $e ) {
			throw new BaseHandlerException(
				$this->parseDynamicException( 'error', $e->getMessage() )
			);
		}
	}

	/**
	 * @param $settings
	 *
	 * @return array
	 * @throws BaseHandlerException
	 */
	public function prepare_subscriber() {
		$settings = $this->getSettings();
		$request  = $this->getRequestData();
		$response = array();

		if ( ! isset( $settings['fields_map'] ) || ! $settings['fields_map'] ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		foreach ( $settings['fields_map'] as $param => $field ) {
			if ( empty( $field ) || empty( $request[ $field ] ) ) {
				continue;
			}
			$response[ $param ] = $request[ $field ];
		}

		return $response;
	}

	public function prepare_list_ids() {
		$settings = $this->getSettings();

		if ( isset( $settings['list_ids'] ) ) {
			$ids = array_filter( $settings['list_ids'], function ( $val, $id ) {
				return ( is_int( $id ) && $val );
			}, ARRAY_FILTER_USE_BOTH );

			return array_keys( $ids );
		}

		return [];
	}


}