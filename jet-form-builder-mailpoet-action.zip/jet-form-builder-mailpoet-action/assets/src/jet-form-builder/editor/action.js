import { getLocalizedFullPack } from "@/source";

const { source, label, help } = getLocalizedFullPack;
const { __ } = wp.i18n;

const {
		  ToggleControl,
		  BaseControl,
		  SelectControl,
		  CheckboxControl,
	  } = wp.components;

const {
		  addAction,
		  getFormFieldsBlocks,
	  } = JetFBActions;

const {
		  ActionFieldsMap,
		  WrapperRequiredControl,
		  RequestLoadingButton,
	  } = JetFBComponents;

addAction( 'mailpoet', function MailPoetAction( {
													settings,
													onChange,
													onChangeSetting,
													getMapField,
													setMapField,
												} ) {
	const onValidApiKey = ( { data } ) => {
		onChange( {
			...settings,
			response:   data,
			isValidAPI: true,
		} );
	};

	const formFieldsList = getFormFieldsBlocks( [], '--' );

	const onInvalidApiKey = () => {
		onChangeSetting( false, 'isValidAPI' );
	};

	return <>
		<BaseControl
			key={ 'hubspot_key_inputs' }
			className="input-with-button"
			label={ label( 'sync' ) }
		>
			<RequestLoadingButton
				ajaxArgs={ { action: source.action } }
				label={ label( 'make_request' ) }
				onSuccessRequest={ onValidApiKey }
				onFailRequest={ onInvalidApiKey }
			/>
		</BaseControl>
		{ settings.isValidAPI && <>
			{ Boolean( settings.response
				&& settings.response.lists
				&& settings.response.lists.length )
			&& <BaseControl
				label={ label( 'list_ids' ) }
				key="before_payment_base_control"
			>
				<div className={ 'checkboxes-row' }>
					{ settings.response.lists.map(
						list => <CheckboxControl
							className={ 'jet-forms-checkbox-field' }
							key={ `place_holder_block_${ list.value }` }
							checked={ getMapField( {
								source: 'list_ids',
								name:   list.value,
							} ) }
							label={ list.label }
							help={ list.desc }
							onChange={ value => setMapField( {
								value,
								source:    'list_ids',
								nameField: list.value,
							} ) }
						/> ) }
				</div>
			</BaseControl> }
			<ToggleControl
				key={ 'send_confirmation_email' }
				label={ label( 'send_confirmation_email' ) }
				checked={ settings.send_confirmation_email }
				onChange={ enable => {
					onChangeSetting( Boolean( enable ), 'send_confirmation_email' )
				} }
			/>
			<ToggleControl
				key={ 'schedule_welcome_email' }
				label={ label( 'schedule_welcome_email' ) }
				checked={ settings.schedule_welcome_email }
				onChange={ enable => {
					onChangeSetting( Boolean( enable ), 'schedule_welcome_email' )
				} }
			/>
			<ToggleControl
				key={ 'skip_subscriber_notification' }
				label={ label( 'skip_subscriber_notification' ) }
				checked={ settings.skip_subscriber_notification }
				onChange={ enable => {
					onChangeSetting( Boolean( enable ), 'skip_subscriber_notification' )
				} }
			/>
			<ActionFieldsMap
				label={ label( 'fields_map' ) }
				fields={ Object.entries( settings.response.fields ) }
			>
				{ ( { fieldId, fieldData, index } ) => <WrapperRequiredControl
					field={ [ fieldId, fieldData ] }
				>
					<SelectControl
						key={ fieldId + index }
						value={ getMapField( { name: fieldId } ) }
						onChange={ value => setMapField( { nameField: fieldId, value } ) }
						options={ formFieldsList }
					/>
				</WrapperRequiredControl> }
			</ActionFieldsMap>
		</> }
	</>;
} );
