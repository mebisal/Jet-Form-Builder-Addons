<?php
/**
 * Start from template
 */
?>
<form <?php $this->render_attributes_string(); ?>>