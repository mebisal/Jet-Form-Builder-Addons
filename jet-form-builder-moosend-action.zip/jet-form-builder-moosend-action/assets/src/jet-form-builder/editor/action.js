import { getLocalizedFullPack } from "@/source";

const { source, label, help } = getLocalizedFullPack;
const { __ } = wp.i18n;

const {
	      TextControl,
	      BaseControl,
	      SelectControl,
	      ToggleControl,
      } = wp.components;

const {
	      addAction,
	      getFormFieldsBlocks,
	      globalTab,
      } = JetFBActions;

const {
	      ActionFieldsMap,
	      WrapperRequiredControl,
	      ValidateButton,
      } = JetFBComponents;

const currentTab = globalTab( { slug: 'moosend' } );

addAction( 'moosend', function MooSendAction( {
	                                              settings,
	                                              onChange,
	                                              onChangeSetting,
	                                              getMapField,
	                                              setMapField,
                                              } ) {
	const onValidApiKey = ( { data } ) => {
		onChange( {
			...settings,
			response: data,
			isValidAPI: true,
		} );
	};

	const formFieldsList = getFormFieldsBlocks( [], '--' );

	const onInvalidApiKey = () => {
		onChangeSetting( false, 'isValidAPI' );
	};

	const apiKey = () => settings.use_global ? currentTab.api_key : settings.api_key;

	const ajaxArgs = {
		action: source.action,
		api_key: apiKey(),
	};

	const placeholder = { value: '', label: '--' };

	const fields = () => {
		return settings.response.fields[ settings.mailing_list ]
			? Object.entries( settings.response.fields[ settings.mailing_list ] )
			: [];
	};

	return <>
		<ToggleControl
			key={ 'use_global' }
			label={ label( 'use_global' ) }
			checked={ settings.use_global }
			onChange={ use_global => {
				onChangeSetting( Boolean( use_global ), 'use_global' )
			} }
		/>
		<BaseControl
			key={ 'hubspot_key_inputs' }
			className="input-with-button"
		>
			<TextControl
				key='api_key'
				label={ label( 'api_key' ) }
				disabled={ settings.use_global }
				value={ apiKey() }
				onChange={ newVal => {
					onChangeSetting( newVal, 'api_key' )
				} }
			/>
			<ValidateButton
				initialValid={ ( apiKey() && settings.isValidAPI ) }
				ajaxArgs={ ajaxArgs }
				label={ settings.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }
				onValid={ onValidApiKey }
				onInvalid={ onInvalidApiKey }
			/>
		</BaseControl>
		<div className='margin-bottom--small'>{ help( 'help_prefix' ) } <a
			href={ help( 'help_link' ) }>{ help( 'help_suffix' ) }</a>
		</div>
		{ settings.isValidAPI && <>
			<ToggleControl
				key={ 'double_opt_in' }
				label={ label( 'double_opt_in' ) }
				checked={ settings.double_opt_in }
				onChange={ newVal => onChangeSetting( Boolean( newVal ), 'double_opt_in' ) }
			/>
			<SelectControl
				label={ label( 'mailing_list' ) }
				labelPosition="side"
				value={ settings.mailing_list }
				onChange={ newVal => onChangeSetting( newVal, 'mailing_list' ) }
				options={ [ placeholder, ...settings.response.mailing_list ] }
			/>
			{ settings.mailing_list && <ActionFieldsMap
				label={ label( 'fields_map' ) }
				fields={ fields() }
			>
				{ ( { fieldId, fieldData, index } ) => <WrapperRequiredControl
					field={ [ fieldId, fieldData ] }
				>
					<SelectControl
						key={ fieldId + index }
						value={ getMapField( { name: fieldId } ) }
						onChange={ value => setMapField( { nameField: fieldId, value } ) }
						options={ formFieldsList }
					/>
				</WrapperRequiredControl> }
			</ActionFieldsMap> }
		</> }
	</>;
} );
