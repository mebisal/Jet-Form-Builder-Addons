const { __ } = wp.i18n;

const helpLink = {
	help_prefix: __( 'How to obtain your Moosend API Key? More info' ),
	help_suffix: __( 'here' ),
	help_link: 'https://help.moosend.com/hc/en-us/articles/208061865-How-do-I-connect-to-the-Moosend-Web-API',
};

export { helpLink };