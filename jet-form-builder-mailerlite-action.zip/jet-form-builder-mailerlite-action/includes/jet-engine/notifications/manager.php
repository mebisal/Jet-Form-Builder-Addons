<?php


namespace Jet_FB_MailerLite\Jet_Engine\Notifications;


use Jet_FB_MailerLite\Plugin;
use JetMailerLiteCore\JetEngine\NotificationsManager;

class Manager extends NotificationsManager {

	public function register_notification() {
		return array(
			new Notification()
		);
	}

	/**
	 * Register notification assets
	 * @return void
	 */
	public function register_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/js/engine.editor.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}

	public function plugin_version_compare() {
		return '2.8.3';
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}

}