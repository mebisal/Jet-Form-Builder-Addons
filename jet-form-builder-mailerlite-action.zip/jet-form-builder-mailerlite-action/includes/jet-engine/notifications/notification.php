<?php


namespace Jet_FB_MailerLite\Jet_Engine\Notifications;


use Jet_FB_MailerLite\Base_Action;
use Jet_FB_MailerLite\Plugin;
use JetMailerLiteCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use Base_Action;

}