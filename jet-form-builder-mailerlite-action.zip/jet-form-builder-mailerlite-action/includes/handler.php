<?php


namespace Jet_FB_MailerLite;


use JetMailerLiteCore\BaseHandler;
use JetMailerLiteCore\Common\Tools;
use JetMailerLiteCore\Exceptions\ApiHandlerException;

class Handler extends BaseHandler {

	protected $api_base_url = 'https://api.mailerlite.com/api/v2/';

	public function ajax_action(): string {
		return 'jet_form_builder_get_mailerlite_data';
	}

	public function get_api_request_args() {
		return array(
			'headers' => array(
				'X-MailerLite-ApiKey' => $this->api_key
			)
		);
	}

	/**
	 * @return mixed
	 * @throws ApiHandlerException
	 */
	public function get_all_data() {
		$groups = $this->get_request( 'groups' );
		$fields = $this->get_request( 'fields' );

		$groups = Tools::with_placeholder( Tools::prepare_list_for_js( $groups, 'id', 'name' ) );
		$fields = $this->prepare_list( $fields, 'title' );

		$fields['email']['required'] = true;

		return array(
			'fields' => $fields,
			'groups' => $groups
		);
	}

	/**
	 * @param $endpoint
	 *
	 * @return array|false|mixed
	 * @throws ApiHandlerException
	 */
	public function get_request( $endpoint ) {
		$response = $this->request( $endpoint );

		if ( isset( $response['error'] ) ) {
			throw new ApiHandlerException( "Error on request /$endpoint", $response['error'], $this->api_request_args );
		}

		return $response;
	}

	private function prepare_list( $source, $label_name, $key_name = 'key' ) {
		$result = array();

		foreach ( $source as $item ) {
			$result[ $item[ $key_name ] ] = array( 'label' => $item[ $label_name ] );
		}

		return $result;
	}
}