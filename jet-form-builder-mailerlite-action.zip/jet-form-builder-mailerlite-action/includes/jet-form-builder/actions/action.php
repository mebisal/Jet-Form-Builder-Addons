<?php

namespace Jet_FB_MailerLite\Jet_Form_Builder\Actions;

use Jet_FB_MailerLite\Base_Action;
use JetMailerLiteCore\JetFormBuilder\SmartBaseAction;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define Base_Type class
 */
class Action extends SmartBaseAction {

	use Base_Action;

	protected function getGlobalSettingsKeys() {
		return array( 'api_key' => '' );
	}
}


