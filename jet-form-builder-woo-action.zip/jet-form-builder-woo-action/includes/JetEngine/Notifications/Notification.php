<?php


namespace Jet_FB_Woo\JetEngine\Notifications;


use Jet_FB_Woo\ActionTrait;
use JetWooCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use ActionTrait;

}