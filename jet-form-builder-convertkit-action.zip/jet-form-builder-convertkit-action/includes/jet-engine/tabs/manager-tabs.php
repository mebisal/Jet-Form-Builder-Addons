<?php


namespace Jet_FB_ConvertKit\Jet_Engine\Tabs;


use JetConvertKitCore\JetEngine\RegisterFormTabs;

class Manager_Tabs {

	use RegisterFormTabs;

	public function tabs(): array {
		return array(
			new Convert_Kit_Tab()
		);
	}

	public function plugin_version_compare() {
		return '2.8.3';
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}

}