import { getLocalizedFullPack } from "@/source";

const { source, label, help } = getLocalizedFullPack;
const { __ } = wp.i18n;

const {
	TextControl,
	BaseControl,
	SelectControl,
	ToggleControl,
} = wp.components;

const {
	addAction,
	getFormFieldsBlocks,
	globalTab
} = JetFBActions;

const {
	ActionFieldsMap,
	WrapperRequiredControl,
	RequestLoadingButton,
	ValidateButton,
	PlaceholderMessage,
} = JetFBComponents;

const currentTab = globalTab( { slug: 'convert-kit-tab' } );

addAction( 'convertkit', function ConvertKit( {
												  settings,
												  onChange,
												  onChangeSetting,
												  getMapField,
												  setMapField
											  } ) {

	const onValidApiKey = ( { data } ) => {
		onChange( {
			...settings,
			response: data,
			isValidAPI: true
		} );
	};

	const formFieldsList = getFormFieldsBlocks( [], '--' );

	const onInvalidApiKey = () => {
		onChangeSetting( false, 'isValidAPI' );
	};

	const apiKey = () => settings.use_global ? currentTab.api_key : settings.api_key;

	const ajaxArgs = {
		action: source.action,
		api_key: apiKey(),
	};

	return <>
		<ToggleControl
			key={ 'use_global' }
			label={ label( 'use_global' ) }
			checked={ settings.use_global }
			onChange={ use_global => {
				onChangeSetting( Boolean( use_global ), 'use_global' )
			} }
		/>
		<BaseControl
			key={ 'mailer_lite_key_inputs' }
			className="input-with-button"
		>
			<TextControl
				key='api_key'
				label={ label( 'api_key' ) }
				disabled={ settings.use_global }
				value={ apiKey() }
				onChange={ newVal => {
					onChangeSetting( newVal, 'api_key' )
				} }
			/>
			<ValidateButton
				initialValid={ ( apiKey() && settings.isValidAPI ) }
				ajaxArgs={ ajaxArgs }
				label={ settings.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }
				onValid={ onValidApiKey }
				onInvalid={ onInvalidApiKey }
			/>
		</BaseControl>
		<div className='margin-bottom--small'>{ help( 'api_key_link_prefix' ) } <a
			href={ help( 'api_key_link' ) }>{ help( 'api_key_link_suffix' ) }</a>
		</div>
		{ ( ! settings.isValidAPI || 1 >= settings.response.tags.length ) && <PlaceholderMessage>
			{ __( 'You do not have any Tags available, you can create them ' ) }
			<a href="https://app.convertkit.com/subscribers">{ __( 'here' ) }</a>
		</PlaceholderMessage> }
		{ ( settings.isValidAPI && 1 < settings.response.tags.length ) && <>
			<BaseControl
				key={ 'convertkit_tag_id' }
				className="input-with-button"
			>
				<SelectControl
					key='group_id'
					label={ label( 'tag_id' ) }
					labelPosition="side"
					value={ settings.tag_id }
					onChange={ newVal => onChangeSetting( newVal, 'tag_id' ) }
					options={ settings.response.tags }
				/>
				<RequestLoadingButton
					ajaxArgs={ ajaxArgs }
					label={ label( 'update_tag_ids' ) }
					onSuccessRequest={ onValidApiKey }
					onFailRequest={ onInvalidApiKey }
				/>
			</BaseControl>
			<ActionFieldsMap
				label={ label( 'fields_map' ) }
				fields={ Object.entries( settings.response.fields ) }
			>
				{ ( { fieldId, fieldData, index } ) => <WrapperRequiredControl
					field={ [ fieldId, fieldData ] }
				>
					<SelectControl
						key={ fieldId + index }
						value={ getMapField( { name: fieldId } ) }
						onChange={ value => setMapField( { nameField: fieldId, value } ) }
						options={ formFieldsList }
					/>
				</WrapperRequiredControl> }
			</ActionFieldsMap>
		</> }
	</>;
} );
