import { Actions } from "jfb-editor";

const { __ } = wp.i18n;

const getLocalizedFullPack = new Actions.EditorData( 'convertkit' )
.setLabels( {
	api_key: __( 'API Key:' ),
	validate_api_key: __( 'Validate API Key' ),
	retry_request: __( 'Retry request' ),
	tag_id: __( 'Tag:' ),
	update_tag_ids: __( 'Update Tags List' ),
	fields_map: __( 'Fields Map:' ),
	use_global: __( 'Use Global Settings' )
} )
.setHelp( {
	api_key_link_prefix: __( 'How to obtain your ConvertKit API Key? More info' ),
	api_key_link_suffix: __( 'here' ),
	api_key_link: 'https://debounce.io/resources/help-desk/integrations/getting-a-convertkit-api-key/',
	fields_map: __( 'Set form fields names to to get user data from' ),
} )
.setGatewayAttrs( [
	"tag_id"
] )
.setSource( {
	action: 'jet_form_builder_get_convertkit_data',
} )
.exportAll();

export { getLocalizedFullPack };